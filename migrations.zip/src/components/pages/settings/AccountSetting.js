import React, { Component } from 'react';
import { Button } from 'react-bootstrap';
import Sidebar from './Sidebar'
const Axios = require('axios');

class AccountSetting extends Component {

    constructor(props) {
        super(props)
        this.state = {
          loading: true,
        }
      }

        profileSetting = (account, username, email, biography) => {
          Axios.post("http://localhost:3001/users/insert", {
             account : account,
             username : username,
             email : email,
            biography : biography,
            })
            .then(() =>{
               alert("SuccessFully Inserted")
              
            })
            .catch(error => {
                console.log(error.response)
            });
            window.location.reload();
        }

    render() {
        return (
            <div>
              <h1>{this.props.username}</h1>
                <form onSubmit={(event) => {
                      event.preventDefault()
                        const username = this.username.value
                        const email = this.email.value
                        const biography = this.biography.value
                        const account =  this.props.account
                        //data send to solidity
                      this.profileSetting(account, username, email, biography)
                      }}>
                <div className="col-lg-8 py-4 mx-auto">

                       <div className="form-group mr-sm-2 mb-4">
                            <label class="CollectionForm--label" for="name">Username*</label>
                            <input
                               id="username"
                               type="text"
                               for="name"
                               ref={(input) => { this.username = input }}
                               className="form-control"
                               placeholder="User Name"
                               required />
                         </div>
                          <div className="form-group mr-sm-2  mb-4">
                          <label class="CollectionForm--label" for="email">Email</label> 
                          <input
                              id="email"
                              type="email"
                              for="email"
                              ref={(input) => { this.email = input }}
                              className="form-control"
                              placeholder="Email"
                              required />
                          </div>
                            <div className="form-group mr-sm-2  mb-4">
                            <label class="CollectionForm--label" for="biography">Biography</label> 
                            <p>Here 0 of 1000 characters used</p>
                              <textarea
                                  id="biography"
                                  type="textarea"
                                  for="biography"
                                  rows="5"
                                  ref={(input) => { this.biography = input }}
                                  className="form-control"
                                  placeholder="Biography"
                                  required />
                              </div>
                              <Button  type = 'submit'  className = "createBtn"> Submit </Button>
                 </div>


                </form>
            </div>
        );
    }
}

export default AccountSetting;






// const AccountSetting = ()=> { 
//      const [ProfileName, setProfileName] = useState('')
//      const [ProfileEmail, setProfileEmail] = useState('')
//      const [ProfileDes, setProfileDes] = useState('')
    


  
//     // console.log(fetchedData)
//     return (
//         <div >
//           <div className = 'row'>
//               <div className = 'col-md-3'>
//                         <Sidebar/>
//               </div>

//             <div className="col-md-7 py-4">
//                  <div className = 'mt-5 mb-3 CreteClton'>  <h1>Edit Profile</h1> </div>
//               <hr></hr>
//             <form onSubmit={(event) => {
//                       event.preventDefault()
//                         const name = this.productName.value
//                         const price = window.web3.utils.toWei(this.productPrice.value.toString(), 'Ether')
//                         const description = this.productDescription.value
//                         const imageHash = this.state.buffer
//                         const category = this.state.category
//                         //data send to solidity
//                       this.createProduct(name, imageHash, price,category, description )
//                       }}>
//                       <div className="form-group mr-sm-2 mb-4">
//                             <label class="CollectionForm--label" for="name">Name*</label>
//                             <input
//                                type="text"
//                                for="name"
//                                onChange={(e) => setProfileName(e.target.value)}
//                                className="form-control"
//                                placeholder="Name*"
//                                required />
//                          </div>
//                          <div className="form-group mr-sm-2 mb-4">
//                             <label class="CollectionForm--label" for="email">Email</label>
//                             <input
//                                type="email"
//                                for="email"
//                                onChange={(e) => setProfileEmail(e.target.value)}
//                                className="form-control"
//                                placeholder="Email*"
//                                required />
//                          </div>
//                          <div className="form-group mr-sm-2  mb-4">
//                             <label class="CollectionForm--label" for="description">Bio</label> 
//                               <textarea
//                                   type="textarea"
//                                   for="description"
//                                   rows="5"
//                                   onChange={(e) => setProfileDes(e.target.value)}
//                                   className="form-control"
//                                   placeholder="Bio"
//                                   required />
//                               </div>
//                 <Button variant="primary" type="submit">
//                         Submit
//                 </Button>
//                 </form>
//             </div>
//             </div>       
//         </div>
//     )
// }
// export default AccountSetting
